/*
Student ID: 301236904
Name: Matheus Teixeira
Assignment: Lab 6
*/
public enum TransactionType {
    DEPOSIT,
    WITHDRAW;
}
